Group: F
Please Note to delete the file.dat file after running the unit tests as the file may not have been cleared and may create errors when running the frontend. Google drive is creating a docx file in docs I cannot get rid of please disregard this.

Package includes:
Project 
	UnitTest - all unit tests	
	docs - all documentation (use cases, descriptions, user manuals)
	templates - all html templates
	authentication.py - authentication module
	Auto_Grading.py - auto grading module
	createQuiz.py - create quiz module
	ManualGrading.py - manual grading module
	persist.py - persistence module
	TakeQuiz.py - take quiz module
	frontend.py - frontend flask code

To Run Tests:
python3 -m unittest discover project.UnitTests


To Run the frontend:

1.Create a virtual environment
	- open terminal
	- navigate to the directory you want to place your environment
	- then call python3 -m venv flaskEnv

2.Download flask
	- open terminal
	- navigate to where flaskEnv is held
	- activate the environment calling . flaskEnv/bin/activate
	- then download flask calling pip install Flask

3.Run the frontend
	- open terminal
	- navigate to the directory which hold the assignment 5 files
	- within the assignment 5 folder call export FLASK_APP=frontend.py
	- then call flask run

4.View the page
	- open a browser
	- navigate to localhost:5000 to view the page