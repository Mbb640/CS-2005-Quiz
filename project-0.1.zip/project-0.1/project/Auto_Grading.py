""" Automatic Grading of Quizzes and Retriving Stats

Mark student MC quizzes and store results to a persistance memory. Will also be
able to retrive the data from persistance memory in a format that will allow it
to be displayed by associate flask module.

Functions:
    correct_quiz - returns value of questions answered corrent
    find_class_average - returns class average of a quiz
    get_student_attempts - returns scores of students attempts at a quiz
    max_score - get best score for a test
    view_student_quiz - returns the collection of questions and answers for a quiz
    
"""
import persist

__all__ = ["max_score","correct_quiz","find_class_average","find_student_average"
           ,"get_student_attempts","view_student_quiz","get_instructor_quizzes"]

file = 'file.dat'

def max_score(quiz):
    """Calculate max score for a test

    Parameter
    ----------
    quiz : str
        Name of a quiz object to beretrieved from the persistance 

    Returns
    -------
    int
       Returns max score available for quiz
    """
    if not isinstance(quiz, str):
        raise TypeError("Invalid quiz")
    storage = persist.Persist(file)
    total = 0

    questions = storage.get_quiz(quiz).questions
    for question in questions:
        total += int(question.value)
    storage.close()
    return total

def correct_quiz(student,quiz, attempt):
    """Take Answers class and give it a score
    
    Parameter
    ----------
    student : str
        Username for Student object to be retrived from the persistance
    quiz : str
        Name of a quiz object to beretrieved from the persistance
    attempt : int
        Index of attempt to be retrieved

    Returns
    -------
    int
       Returns score for a completed quiz
    """
    if not isinstance(quiz, str):
        raise TypeError("Invalid answer set")

    storage = persist.Persist(file)
    students = storage.list_students()
    for stu in students:
        if stu.email == student:
            stud = stu
            result = stu.quizzes[quiz][1][attempt-1]
            break

    score = 0
    for x in range(len(result.student_answers)):
        if result.student_answers[x] in result.correct_answers[x]:
           score += int(result.question_weights[x])
    result.score = score
              
    if score > stud.quizzes[quiz][0]:
        stud.quizzes[quiz][0] = score

    storage.storage['students'] = students
    storage.close()
    return score

def find_class_average(quiz):
    """Find average for a class for a single quiz

    Parameter
    ----------
    quz : str
        Name of a Quiz object to be retrieved from the persistance 

    Returns
    -------
    int
       Returns average score of all able students for quiz
    """
    if not isinstance(quiz, str):
        raise TypeError("Invalid quiz")
    storage = persist.Persist(file)
    data = storage.storage
    average = 0
    students = storage.get_quiz(quiz).students
    for student in data['students']:
        if student.email in students:
            average += student.quizzes[quiz][0]
    average = average/len(students)

    storage.close()
    return average

def find_student_average(student, quiz):
    """Find average score between attempts of one quiz

    Parameter
    ----------
    student : str
        Username for Student object to be retrived from the persistance
    quiz : str
        Name of Quiz object to be retrieved from the persistance

    Returns
    -------
    int
       Returns average rounded to int of student's attemps

    """
    if not isinstance(student, str):
        raise TypeError("Invalid student")
    if not isinstance(quiz, str):
        raise TypeError("Invalid quiz")
    attempts = get_student_attempts(student,quiz)
    while None in attempts:
        attempts.remove(None)
    if len(attempts) == 0:
        return 0
    average = sum(attempts)/len(attempts)

    return average

def get_student_attempts(student, quiz):
    """Return score from all attempts for student

    Parameter
    ----------
    student : str
        Username for Student object to be retrived from the persistance
    quiz : str
        Name of Quiz object to be retrieved from the persistance

    Returns
    -------
    int
       Returns a list of scores of student's attemps

    """
    if not isinstance(student, str):
        raise TypeError("Invalid student")
    if not isinstance(quiz, str):
        raise TypeError("Invalid quiz")
    storage = persist.Persist(file)
    data = storage.storage
    students = data['students']
    for stu in students:
        if stu.email == student:
            attempts = stu.quizzes[quiz][1]
            scores = []
            for attempt in attempts:
                if attempt:
                    if attempt.submitted:
                        ###
                        #get Mackenzies to add score variable to Answers
                        scores.append(attempt.score)
                else:
                    scores.append(None)
            storage.close()
            return scores
    storage.close()
    raise ValueError("Data not found")

def view_student_quiz(student, quiz, attempt):
    """Retrieve questions for quiz, the correct answers,
       and a students answers to be displayed

    Parameter
    ----------
     student : str
        Username for Student object to be retrived from the persistance
    quiz : Quiz
        An Quiz object retrieved from the persistance
    attempt : int
        Index of attempt to be retrieved

    Returns
    -------
    list
       Returns list of tuples that contain parts of a
       completed quiz which will be displayed

    """
    if not isinstance(student, str):
        raise TypeError("Invalid quiz")
    if not isinstance(quiz, str):
        raise TypeError("Invalid answer set")
    storage = persist.Persist(file)
    data = storage.storage
    for stu in data['students']:
        if stu.email == student:
            result = stu.quizzes[quiz][1][attempt-1]
            break
    
    toReturn = []

    quiz = storage.get_quiz(quiz)
    
    for x, question in enumerate(quiz.questions):
        toReturn.append((question.text, result.correct_answers[x]
                         ,result.student_answers[x]))

    storage.close()            
    return toReturn

def get_instructor_quizzes(instructor):
    """Retrieve all quizzes in storage made by the instructor

    Parameter
    ----------
    instructor : Instructor
        An Instructor object retrieved from the persistance

    Returns
    -------
    list
        Returns the complete list of quiz names made by the
        given instructor
    """
    if not isinstance(instructor, str):
        raise TypeError("Input must be string")
    storage = persist.Persist(file)
    data = storage.storage

    inst_quizzes = []
    quizzes = data['quizzes']
    for quiz in quizzes:
        if quiz.creator == instructor:
            inst_quizzes.append(quiz.Name)
    storage.close()
    return inst_quizzes
