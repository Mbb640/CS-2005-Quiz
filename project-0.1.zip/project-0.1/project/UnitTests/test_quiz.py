import unittest
from createQuiz import Quiz, Question, Instructor, Persist
import createQuiz
import authentication


class testQuiz(unittest.TestCase):

    def test_authorize(self):
        q = Quiz("",[],5,4,3,"jtpnoel")
        self.assertEqual(q.authorize("jtpnoel"), True)
        
    def test_authorize_fail(self):
        q = Quiz("",[],5,4,3,"jtpnoel")
        with self.assertRaises(PermissionError):
            q.authorize("Not Correct")
    
    def test_addQuest(self):
        q = Quiz("",[],5,4,3,"jtpnoel")
        quest = Question("Test",[],[],3)
        q.addQuestion(quest,"jtpnoel")
        self.assertEqual(quest, q._findQuestion(quest))
    
    def test_addFail(self):
        q = Quiz("",[],5,4,3,"jtpnoel")
        quest = "This should Fail"
        with self.assertRaises(TypeError):
            q.addQuestion(quest,"jtpnoel")
    
    def test_removeQuest(self):
        q = Quiz("",[],5,4,3,"jtpnoel")
        quest = Question("Pass",[],[],3)
        q.addQuestion(quest,"jtpnoel")
        q.removeQuestion(quest,"jtpnoel")
        self.assertEqual(q.questions, [])
    
    def test_removeFail(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        quest = Question("Fail", [],[],3)
        with self.assertRaises(ValueError):
            q.removeQuestion(quest,"jtpnoel")
    
    def test_modifyValue(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        quest = Question("Pass", [],[],3)
        q.addQuestion(quest,"jtpnoel")
        q.modifyQuestionValue(quest, 5, "jtpnoel")
        self.assertEqual(q._findQuestion(quest).value, 5)
    
    def test_modifyFail(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        quest = Question("Pass", [],[],3)
        with self.assertRaises(ValueError):
            q.modifyQuestionValue(quest,-3,"jtpnoel")
    
    def test_changeStart(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        q.changeStart("5","jtpnoel")
        self.assertEqual(q.startTime, "5")

    def test_StartFail(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        with self.assertRaises(TypeError):
            q.changeStart(5,"jtpnoel")

    def test_changeEnd(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        q.changeEnd("5","jtpnoel")
        self.assertEqual(q.endTime, "5")
    
    def test_endFail(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        with self.assertRaises(TypeError):
            q.changeEnd(5,"jtpnoel")
    
    def test_addStudents(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        authentication.create_account("Tester123")
        q.addStudents("Tester123","jtpnoel")
        self.assertEqual(q.students[0], "Tester123")
    
    def test_failStudents(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        with self.assertRaises(ValueError):
            q.addStudents("not a user","jtpnoel")
    
    #There cannot be a failure for this
    def test_copyQuiz(self):
        q = Quiz("",[],4,3,3,"jtpnoel")
        x = q.copyQuiz("jtpnoel")
        self.assertEqual(x.Name, q.Name)   

    def test_QuestionAddChoice(self):
        q = Question("Test",[],[],3)
        q.addChoice("Test")
        exists = False
        for i in q.choices:
            if i == "Test":
                exists = True
        self.assertEqual(exists, True) 

    def test_QuestionAddChoiceFail(self):
        q = Question("Test",[],[],3)
        with self.assertRaises(TypeError):
            q.addChoice(6)
    
    def test_QuestionRemoveChoice(self):
        q = Question("Test",["Test"],[],3)
        q.removeChoice("Test")
        self.assertEqual(q.choices, [])
    
    def test_QuestionRemoveChoiceFail(self):
        q = Question("Test1",[],[],3)
        with self.assertRaises(ValueError):
            q.removeChoice("Test")
    
    def test_QuestionChangeValue(self):
        q = Question("Test2",[],[],4)
        q.changeValue(3)
        self.assertEqual(q.value, 3)
    
    def test_QuestionChangeValue(self):
        q = Question("Test",[],[],4)
        with self.assertRaises(ValueError):
            q.changeValue(-2)
    
    #There cannot be a failure for this 
    def test_QuestionCopy(self):
        q = Question("Test3",[],[],4)
        quest = q.copyQuestion()
        self.assertEqual(q, quest)
    
    def test_submitQuiz(self):
        quiz = Quiz("Test4",[],"3","5",3,"jtpnoel")
        createQuiz.submitQuiz(quiz)
        self.assertEqual(createQuiz.Persist("file.dat").get_quiz(quiz), quiz)
    
    def test_submitQuizFail(self):
        quiz = "Fail"
        with self.assertRaises(TypeError):
            createQuiz.submitQuiz(quiz)
    
    def test_addToQBank(self):
        quest = Question("Test5",[1,2],[1],3)
        createQuiz.addToQBank(quest)
        self.assertEqual(createQuiz._getFromQBank(quest), quest)
    
    def test_addToQBankFail(self):
        quest = "Not a Question"
        with self.assertRaises(TypeError):
            createQuiz.addToQBank(quest)
    
    def test_removeFromQBank(self):
        quest = Question("Test6",[1,2],[1],3)
        createQuiz.addToQBank(quest)
        createQuiz.removeFromQBank(quest)
        #If the question isnt in the bank ValueError will be raised
        with self.assertRaises(KeyError):
            createQuiz._getFromQBank(quest)
    
    def test_removeFromQBankFail(self):
        quest = "text"
        with self.assertRaises(KeyError):
            createQuiz.removeFromQBank(quest)
    
    def test_changeAnswersInQBank(self):
        quest = Question("Test7",[1,2],["1"],3)
        createQuiz.addToQBank(quest)
        createQuiz.changeAnswersInQBank(quest, ["1","2","3"])
        self.assertEqual(createQuiz._getFromQBank(quest).answers , ['1','2','3'])
    
    def test_changeAnswersInQBankFail(self):
        quest = Question("Test8",[1,2],[1],3)
        createQuiz.changeAnswersInQBank(quest, [1,2,3])
    
    def test_addOptionsInQBank(self):
        quest = Question("Test9",["1","2"],[1],3)
        createQuiz.addToQBank(quest)
        createQuiz.addOptionsInQBank(quest, "9")
        self.assertEqual(createQuiz._getFromQBank(quest).choices, ["1","2","9"])
    
    def test_addOptionsInQBankFail(self):
        quest = Question("Test10",[1,2],[1],3)
        with self.assertRaises(KeyError):
            createQuiz.addOptionsInQBank(quest, "9")
    
    def test_removeOptionsInQBank(self):
        quest = Question("Test11",[1,2],[1],3)
        createQuiz.addToQBank(quest)
        createQuiz.removeOptionsInQBank(quest, 2)
        self.assertEqual(createQuiz._getFromQBank(quest).choices, [1])

    def test_removeOptionsInQBankFail(self):
        quest = Question("Test12",[1,2],[1],3)
        with self.assertRaises(KeyError):
            createQuiz.removeOptionsInQBank(quest, 9)
    
    def test_copyFromQBank(self):
        quest = Question("Test13",[1,2],[1],3)
        createQuiz.addToQBank(quest)
        compare = createQuiz.copyFromQBank(quest)
        self.assertEqual(quest,compare)
    
    def test_copyFromQBankFail(self):
        quest = Question("Test14",[1,2],[1],3)
        with self.assertRaises(KeyError):
            compare = createQuiz.copyFromQBank(quest)

    #No real way to fail this method
    def test_listQbankTest(self):
        quizzes = createQuiz.listQBank()
        if len(quizzes) > 0:
            pass
    
    def test_deleteQuiz(self):
        quiz = Quiz("Test15",[],"3","5",3,"jtpnoel")
        createQuiz.submitQuiz(quiz)
        createQuiz.deleteQuiz("Test15")
    
    def test_deleteQuizFail(self):
        with self.assertRaises(KeyError):
            createQuiz.deleteQuiz("NotAQuiz")

    def test_getQuiz(self):
        quiz = Quiz("Test20",[],"3","5",3,"jtpnoel")
        createQuiz.submitQuiz(quiz)
        self.assertEqual(quiz, createQuiz.getQuiz(quiz))
    
    def test_getQuizFail(self):
        with self.assertRaises(KeyError):
            createQuiz.getQuiz('DoesntExist')

    #No real way to fail
    def test_getStudentList(self):
        studs = createQuiz.getStudentList()
        self.assertEqual([],studs)
    
    




        
    
if __name__ == "__main__":
    unittest.main(verbosity=2)
