import os
import sys

from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash
from createQuiz import Question, Quiz, submitQuiz, addToQBank, listQBank, _getFromQBank, removeFromQBank, listQuizzes, getQuiz, deleteQuiz, getStudentList
import authentication 
from TakeQuiz import check_permissions, show_quiz, submit_quiz
import Auto_Grading
import ManualGrading


app = Flask(__name__)
app.secret_key = "secretkey"

def isInstructor():
    return authentication.validate_login(session['user'], session['password']) == 'I'

#Module 1
@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/register")
def register():
    return render_template('register.html')

@app.route("/register_result",  methods=['POST', 'GET'])
def register_result():
    user_email = request.form['email']
    user_pass = request.form['psw']
    res = authentication.validate_instructor(user_email, user_pass)
    if res == True:
        text = 'Registration successful. You can now login'
        return render_template('register_result.html', text=text)
    elif res == 'not an instructor':
        text = 'Oops. You are not allowed to register!'
        return render_template('register_result.html', text=text)
    else:
        text = 'Oops. You are already registered. Go ahead and sign in'
        return render_template('register_result.html', text=text)

@app.route("/login")
def login():
    return render_template('login.html')

@app.route("/Ihome")
def Ihome():
    if isInstructor():
        text = "Instructor " + session['user'] + " logged in!"
        return render_template('instructorHome.html', text=text)

@app.route("/Shome")
def studentHome():
    text = "Student " + session['user'] + " logged in!"
    return render_template('slogin_result.html', text=text)

    
@app.route("/login_result", methods=['POST', 'GET'])
def login_result():
    user_email = request.form['email']
    user_pass = request.form['psw']
    if authentication.validate_login(user_email, user_pass) == 'I':

        session['user'] = user_email
        session['password'] = user_pass
        text = 'Instructor' + ' ' + user_email + ' ' + 'logged in!'
        return render_template('instructorHome.html', text=text)
    elif authentication.validate_login(user_email, user_pass) == 'S':

        session['user'] = user_email
        session['password'] = user_pass
        text = 'Student' + ' ' + user_email + ' ' + 'logged in'
        return render_template('slogin_result.html', text=text)
    else:
        session['user'] = None
        text = 'Oops! It seems there is no such a user. Go ahead and sign up!'
        return render_template('login_result.html', text = text)

@app.route("/create_account")
def create_account():
    return render_template('create_account.html')

@app.route("/account_created", methods=['POST', 'GET'])
def account_created():
    student_email = request.form['email']
    result = authentication.create_account(student_email)
    if result == False:
        text1 = 'An account cannot be created for this student!'
        text2 = 'He is either not eligible or already has an account. Check back in your profile page to see the list of eligible students.'
        return render_template('account_created.html', text1 = text1, text2 = text2)
    else:
        password = result
        text1 = 'An account has been created for' + ' ' + student_email + '.'
        text2 = 'This student should use his email and the following password to login: ' + password
        return render_template('account_created.html', text1 = text1, text2 = text2)




#Module 2
@app.route('/createQuiz')
def creating():
    if isInstructor():
        return render_template('start.html')
    else:
        return "You are not authorized to access this"

@app.route('/qbank')
def modify():
    if isInstructor():
        return render_template('qbank.html', bank = listQBank())
    else:
        return "You are not authorized to access this"

@app.route('/removeQ', methods=['POST'])
def removeQ():
    if isInstructor():
        quest = request.form['text']
        removeFromQBank(quest)
        return render_template('qbank.html', bank = listQBank())
    else:
        return "You are not authorized to access this"

@app.route('/createQ', methods=['POST'])
def goToCreate():
    if isInstructor():
        return render_template('createQ.html', bank = listQBank())
    else:
        return "You are not authorized to access this"

@app.route('/createdQ', methods=['POST'])
def create():
    if authentication.validate_login(session['user'], session['password']) == 'I':
        text = request.form['text']
        options = [request.form['option1'], request.form['option2'], request.form['option3'], request.form['option4']]
        answers = []
        ans = request.form.getlist('answer')
        val = int(request.form['weight'])
        for i in ans:
            if i == "A":
                answers.append(request.form['option1'])
            elif i == "B":
                answers.append(request.form['option2'])
            elif i == "C":
                answers.append(request.form['option3'])
            elif i == "D":
                answers.append(request.form['option4'])
                           
        question = Question(text,options,answers,val)
        addToQBank(question)
        return render_template('qbank.html', bank = listQBank())
        

@app.route('/Quiz', methods=['POST'])
def viewingQuiz():
    if authentication.validate_login(session['user'], session['password']) == 'I':
        name = request.form['name']
        startTime = request.form['start']
        startDate = request.form['startdate']
        start = startTime + ", " + startDate
        endTime = request.form['end']
        endDate = request.form['enddate']
        end = endTime + ", " + endDate
        attempts = request.form['attempts']
        global quiz
        quiz = Quiz(name,[],start,end,int(attempts),session['user'])
        return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())

@app.route('/main')
def main():
    return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())
    

@app.route('/CreateQuestion', methods=['POST'])
def printQuest():
    if authentication.validate_login(session['user'], session['password']) == 'I':
        text = request.form['text']
        options = [request.form['option1'], request.form['option2'], request.form['option3'], request.form['option4']]
        answers = []
        ans = request.form.getlist('answer')
        val = request.form['weight']
        for i in ans:
            if i == "A":
                answers.append(request.form['option1'])
            elif i == "B":
                answers.append(request.form['option2'])
            elif i == "C":
                answers.append(request.form['option3'])
            elif i == "D":
                answers.append(request.form['option4'])
                           
        question = Question(text,options,answers,val)
        addToQBank(question)
        quiz.addQuestion(question,session['user'])

        return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())

@app.route('/Remove', methods=['POST'])
def removeQuest():
    quest = request.form['Delete']
    quiz.removeQuestion(quest, session['user'])
    return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())

@app.route('/value', methods=['POST'])
def editQuest():
    quest = request.form['changeVal']
    val = request.form['value']
    quiz.modifyQuestionValue(quest,int(val),session['user'])
    return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())

@app.route("/add",methods=['POST'])
def fromQuizBank():
    q = request.form['Add']
    quest = _getFromQBank(q)
    quiz.addQuestion(quest, session['user'])
    return render_template('lay.html', questions=quiz.questions, quiz=quiz.Name, bank=listQBank())


@app.route('/submit', methods=['POST'])
def subQuest():
    submitQuiz(quiz)
    return render_template('submission.html')


#Module 3
@app.route('/viewQuizzes')
def view():
    if isInstructor():
        return render_template('viewQuizzes.html', quizzes=listQuizzes())

@app.route('/editQuiz', methods=['POST'])
def editQuiz():
    if isInstructor():
        q = request.form['Edit']
        global quiz
        quiz = getQuiz(q)
        return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route('/changeStart', methods=['POST'])
def changeStart():
    if isInstructor():
        startTime = request.form['start']
        startDate = request.form['startdate']
        start = startTime + ", " + startDate
        qname = request.form['stime']
        q = getQuiz(qname)
        q.changeStart(start, session['user'])
        submitQuiz(q)
        global quiz
        quiz = getQuiz(q)
        return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route('/changeEnd', methods=['POST'])
def changeEnd():
    if isInstructor():
        endTime = request.form['end']
        endDate = request.form['enddate']
        end = endTime + ", " + endDate
        qname = request.form['etime']
        q = getQuiz(qname)
        q.changeEnd(end, session['user'])
        submitQuiz(q)
        global quiz
        quiz = getQuiz(q)
        return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route('/removeEdit', methods=['POST'])
def removeQuestEdit():
    quest = request.form['Delete']
    quiz.removeQuestion(quest, session['user'])
    return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route('/valueEdit', methods=['POST'])
def editQuestEdit():
    quest = request.form['changeVal']
    val = request.form['value']
    quiz.modifyQuestionValue(quest,int(val),session['user'])
    return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(), lst=getStudentList())

@app.route("/addEdit",methods=['POST'])
def addEdit():
    q = request.form['Add']
    quest = _getFromQBank(q)
    quiz.addQuestion(quest, session['user'])
    return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route("/addStudent", methods=['POST'])
def addStud():
    stud = request.form['Add']
    quiz.addStudents(stud, session['user'])
    return render_template('editQuiz.html', questions=quiz.questions, quiz=quiz, bank=listQBank(),lst=getStudentList())

@app.route("/removeQuiz", methods=['POST'])
def removeQuiz():
    q = request.form['Remove']
    deleteQuiz(q)
    return render_template('viewQuizzes.html', quizzes=listQuizzes())

##Take Quiz Module

@app.route("/takeQuiz", methods=['POST','GET'])
def takequiz():
    return render_template('takeQuiz.html', quizzes=check_permissions(session['user']))


@app.route("/takingQuiz", methods=['POST'])
def takingQuiz():
    global answers
    answers = []
    counter = 0
    global t_Quiz
    t_Quiz = request.form['Take']
    global questions
    questions=show_quiz(t_Quiz)
    return render_template('takingQuiz.html',q=questions[counter],count=counter)

@app.route("/submitQuestion", methods=['POST'])
def answersingQ():
    counter = int(request.form['counter'])
    ans = request.form['answer']
    answers.append(ans)
    if counter + 1 <= len(questions):
        counter = int(counter) + 1
        if counter == len(questions):
            string = ""
            string = string + answers[0] 
            for i in range(len(answers)):
                if i == 0:
                    pass
                else:
                    string = string + "|||" + str(answers[i])
            
            submit_quiz(string, session['user'], t_Quiz)
            students = getStudentList()
            for i in students:
                if i.email == session['user']:
                    length = len(i.quizzes[t_Quiz][1])
                    break

            Auto_Grading.correct_quiz(session['user'],t_Quiz,length)
        
            return render_template('quizSub.html')
            
    return render_template('takingQuiz.html',q=questions[counter],count=counter)


@app.route('/viewStudentGrades', methods=['POST'])
def viewIndividualGrades():
    return render_template('viewStudQuizzes.html',quizzes=check_permissions(session['user']))

@app.route('/viewingQuiz', methods=['POST'])
def viewingStudentQuiz():
    studQ = request.form['view']
    global quizzes
    quizzes = getQuiz(studQ)
    students = getStudentList()
    for i in students:
        if i.email == session['user']:
            length = len(i.quizzes[studQ][1])
            break
    viewing = []
    correct = []
    for i in range(0,length):
        viewing.append(Auto_Grading.view_student_quiz(session['user'],studQ,i))
        correct.append(Auto_Grading.correct_quiz(session['user'],studQ,i))
    
    return render_template('viewingresults.html', q=quizzes, studAns=viewing, correcting=Auto_Grading.get_student_attempts(session['user'],studQ)[::-1], max=Auto_Grading.max_score(studQ))

@app.route('/viewInstuctorQuizzes')
def instuctorQuizzes():
    return render_template('viewInstuctorQuizzes.html', quizzes=Auto_Grading.get_instructor_quizzes(session['user']))

@app.route('/viewInstrucResults', methods=['POST'])
def viewingStudentResults():
    global q
    q = request.form['quiz']
    quiz = getQuiz(q)
    students = quiz.students
    lst = getStudentList()
    return render_template('classMarks.html', average = Auto_Grading.find_class_average(q), max = Auto_Grading.max_score(q),studs=students)

@app.route('/viewIndividStud', methods=['POST'])
def viewIndividStud():
    student = request.form['Student']
    quizzes = getQuiz(q)
    students = getStudentList()
    for i in students:
        if i.email == student:
            top = i.quizzes[q][0]
            length = len(i.quizzes[q][1])
            break
    viewing = []
    correct = []
    for i in range(0,length):
        viewing.append(Auto_Grading.view_student_quiz(student,q,i))
    
    return render_template('viewStudResults.html',q=quizzes, studAns=viewing, correcting=Auto_Grading.get_student_attempts(student, q)[::-1], max=Auto_Grading.max_score(q), student = student, topmark=top)

@app.route('/changeMark', methods=['POST'])
def changeMark():
    student = request.form['stud']
    value = int(request.form['weight'])
    quizzes = getQuiz(q)
    ManualGrading.modify_student_quiz_grade(student,q,value)
    students = getStudentList()
    for i in students:
        if i.email == student:
            length = len(i.quizzes[q][1])
            top = i.quizzes[q][0]
            break
    viewing = []
    correct = []
    attempts = Auto_Grading.get_student_attempts(student,q)
    for i in range(0,length):
        viewing.append(Auto_Grading.view_student_quiz(student,q,i))

    return render_template('viewStudResults.html',q=quizzes, studAns=viewing, correcting=Auto_Grading.get_student_attempts(student,q)[::-1], max=Auto_Grading.max_score(q), student = student, topmark=top)

@app.route('/changeAllGrades', methods=['POST'])
def changeAllGrades():
    value = int(request.form['weight'])
    ManualGrading.modify_quiz_grades(q,value)
    quiz = getQuiz(q)
    students = quiz.students
    return render_template('classMarks.html', average = Auto_Grading.find_class_average(q), max = Auto_Grading.max_score(q),studs=students)






    








    
