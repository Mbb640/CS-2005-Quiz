"""
    This module is responsible for checking user permissions, fetching a quiz from persistance, and displaying the quiz to the user.
    If the user submits or pauses their quiz, the module will save their answers and pass them to persistance.
    After a quiz is paused, if the user returns to he quiz, the answers that were saved will automatically be loaded
    back in.

"""
import datetime
from persist import *

def check_permissions(user):
    """Checks the logged-in user's credentials and shows all quizzes available to the user.
       Only shows quizzes that still have available attempts.


    Parameters
    ----------
    user: string
        Id of the user currently logged in.

    Returns
    -------
    available_quizzes : list of Quiz objects
        All quizzes that are available to the user.
    """
    persist = Persist("file.dat")
    exists = False
    tempString = ''
    available_quizzes = []
    for i in persist.list_students():
        if i.email == user:
            exists = True
            quiz_ids = i.quizzes.keys()
            for j in quiz_ids:
                if persist.get_quiz(j).numOfAttempts > len(i.quizzes[j][1]):
                    available_quizzes.append(persist.get_quiz(j))
    if not exists:
        persist.close()
        raise ValueError
    persist.close()
    return available_quizzes


def show_question(quiz, index):
    """Takes a Quiz and an index number, returns a string that contains the question text.
    
    Parameters
    ----------
    quiz: Quiz object
        The quiz that is going to be displayed.
    index: int
        Determines which question is being displayed. Starts from 0.
        
    Returns
    -------
    string
        The text of the question
        
    Raises
    ------
    IndexError when given a negative or number larger than amount of questions in quiz.
    """
    persist = Persist('file.dat')
    if index < 0 or index > len(quiz.questions)-1:
        persist.close()
        raise IndexError
    persist.close()
    return quiz.questions[index].text

def show_quiz(quiz_id):
    """Takes a quiz, returns a string containing all question texts seperated by '|||'

    Parameters
    ----------
    quiz_id
        String that will be used to fetch Quiz object from persistance.
    
    Returns
    -------
    quiz.questions : list of Questions
        The questions for a quiz.
    
    Raises
    ------
    KeyError when asked to get a quiz from persistance that does not exist
    """
    persist = Persist('file.dat')
    try:
        quiz = persist.get_quiz(quiz_id)
    except KeyError:
        persist.close()
        raise KeyError
    return quiz.questions


def submit_quiz(answer_string, student_id, quiz_id):

    """Takes a quiz, saves all answers currently in questions, and sends related Answers to persistence.
    
    Parameters
    ----------
    answer_string : str
        string of answers to a quiz
    student_id : str
        email for the student the quiz belongs to
    quiz_id : str
        quiz that is going to be submitted.
        
    Returns
    -------
    string
        Quiz submitted! If the quiz is submitted
        Unanswered, If the quiz was not and has unanswered questions
    
    Raises
    ------
    Keyerror if student is not found
    ValueError if answer is not in a string format
    """
    persist = Persist("file.dat")
    student = None
    if not isinstance(answer_string, str):
        persist.close()
        raise ValueError
    unanswered=False
    answers = answer_string.split("|||")
    for i in answers:
        if i =="":
            unanswered = True
    for i in persist.list_students():
        if i.email == student_id:
            student = i
    if not student:
        persist.close()
        raise KeyError
    results = Answers(student_id, quiz_id)
    results.submitted = True
    results.save_answers(answer_string)
    student.quizzes[quiz_id][1].append(results)
    if unanswered:
        persist.close()
        return "Unanswered"
    persist.close()
    return "Quiz submitted!"


def pause_quiz(answer_string, student_id, quiz_id):

    """Takes a quiz, saves all answers currently in questions, passes to persistence to be continued later.
    
    Parameters
    ----------
    answer_string : str
        string of answers to a quiz
    student_id : str
        email for the student the quiz belongs to
    quiz_id : str
        quiz that is going to be paused.
    
    Returns
    -------
    string
        Confirmation that quiz was paused.
    Raises
    ------
    KeyError if student_id or quiz_id does not match one in database
    """
    persist = Persist("file.dat")
    student = None
    for i in persist.list_students():
        if i.email == student_id:
            student = i
    if not student:
        persist.close()
        raise KeyError
    results = Answers(student_id, quiz_id)
    results.submitted = True
    results.save_answers(answer_string)
    if quiz_id in student.quizzes.keys():   
        student.quizzes[quiz_id][1].append(results)
    else:
        persist.close()
        raise KeyError
    persist.close()
    return "Quiz paused!"


def resume_quiz(quiz_id, student_id):

    """Checks persistence for quizzes in progress, fills in saved answers.
    
    Parameters
    ----------
    quiz_id : str
        id of quiz object student is trying to access.
    student_id : str
        id of student trying to access quiz.
        
    Returns
    -------
    String
        If quiz attempt found, returns string holding the answers that were filled in when quiz was paused.

    Raises
    ------
        Keyerror if student is not found in persist
    """
    persist = Persist("file.dat")
    student = None
    for i in persist.list_students():
        if i.email == student_id:
            student = i
    if not student:
        persist.close()
        raise KeyError
    resumed_answers = None
    for i in student.quizzes[quiz_id][1]:
        if i.submitted == False:
            resumed_answers = i
            student.quizzes[quiz_id][1].remove(i)
    if not resumed_answers:
        resumed_answers = ''
        for i in persist.get_quiz(quiz_id).questions:
            resumed_answers = resumed_answers + '|||'
        persist.close()
        return resumed_answers
    ret_string = ''
    for i in resumed_answers.student_answers:
        ret_string = ret_string + i + '|||'
        persist.close()
    return ret_string


