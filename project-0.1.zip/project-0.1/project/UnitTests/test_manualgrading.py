import unittest
import ManualGrading
from persist import Student, Instructor, Persist, Quiz, Question, Answers

class TestManualGrading(unittest.TestCase):



    
    def setUp(self):
        storage = Persist('file.dat')
        S = Student('jd@mun.ca',123)
        Q1 = Question("This is a question",['a','b','c','d'],['a'],1)
        Q2 = Question("This is a question2",['a','b','c','d'],['a'],1)
        Q3 = Question("This is a question3",['a','b','c','d'],['a'],1)
        Q4 = Question("This is a question4",['a','b','c','d'],['a'],1)
        Qz = Quiz('Quiz1',[Q1,Q2,Q3,Q4],1,2,3,'joe@mun.ca')
        A = Answers(1,2)
        A.student_answers = ['a','a','b','a']
        A.score = 75
        A.submitted = True
        S.quizzes['Quiz1'] = [75, [A]]
        storage.storage['students'] = [S]
        storage.add_instructor(Instructor('joe@mun.ca',123))
        storage.add_quiz(Qz)
        storage.close()

    def test_modify_student_quiz_grade(self):
        ManualGrading.modify_student_quiz_grade('jd@mun.ca', 'Quiz1', 89)
        storage = Persist('file.dat')
        for s in storage.list_students():
            if s.email == 'jd@mun.ca':
                grade = s.quizzes['Quiz1'][0]
            else: grade = None
        storage.clean()
        self.assertEqual(89, grade)
        storage.close()

    def test_modify_student_quiz_grade_fail(self):
        storage = Persist('file.dat')
        with self.assertRaises(ValueError):
            ManualGrading.modify_student_quiz_grade('jd@mun.ca', "Quiz1", 200)
        with self.assertRaises(KeyError):
            ManualGrading.modify_student_quiz_grade('sam@mun.ca', "Quiz1", 50)
        storage.clean()
        storage.close()

    def test_modify_answer(self):
        ManualGrading.modify_answer('jd@mun.ca','Quiz1',"This is a question",'a')
        storage = Persist('file.dat')
        for s in storage.list_students():
            if s.email == 'jd@mun.ca':
                answer = s.quizzes['Quiz1'][1][0].student_answers[0]
            else: answer = None
        storage.clean()
        self.assertEqual('a', answer)
        storage.close()

    def test_modify_answer_fail(self):
        storage = Persist('file.dat')
        with self.assertRaises(ValueError):
            ManualGrading.modify_answer('jd@mun.ca','Quiz1', "This is a question",['z'])
        with self.assertRaises(KeyError):
            ManualGrading.modify_answer('sam@mun.ca','Quiz1',"This is a question",['b'])
        storage.clean()
        storage.close()

    def test_modify_quiz_grades(self):
        libef = []
        liaft = []
        storage = Persist('file.dat')
        for s in storage.list_students():
            if 'Quiz1' in s.quizzes.keys():
                libef.append(s.quizzes['Quiz1'][0])
        storage.close()
        ManualGrading.modify_quiz_grades('Quiz1',10)
        storage = Persist('file.dat')
        for s in storage.list_students():
            if 'Quiz1' in s.quizzes.keys():
                liaft.append(s.quizzes['Quiz1'][0])
        for i in range(len(libef)):
            self.assertEqual(10, (liaft[i] - libef[i] ))
        storage.clean()
        storage.close()

    def test_modify_quiz_grades_fail(self):
        storage = Persist('file.dat')
        with self.assertRaises(ValueError):
            ManualGrading.modify_quiz_grades('Quiz1',1000)
        storage.clean()
        storage.close()

    def test_new_question_answer(self):
        ManualGrading.new_question_answer('Quiz1', 'This is a question', ['a','b'])
        storage = Persist('file.dat')
        a = storage.get_quiz("Quiz1").questions[0].answers
        self.assertEqual(['a','b'], a)
        storage.clean()
        storage.close()

    def  test_new_question_answer_fail(self):
        storage = Persist('file.dat')
        with self.assertRaises(KeyError):
            ManualGrading.new_question_answer('Quiz1', "This is not a question", ['A'])
        storage.clean()
        storage.close()

    def test_update_grades(self):
        storage = Persist('file.dat')
        for s in storage.list_students():
            if s.email == 'jd@mun.ca':
                stu = s
        stu.quizzes['Quiz1'][0] = 0
        storage.close()
        ManualGrading.update_grades('jd@mun.ca', 'Quiz1')
        storage = Persist('file.dat')
        for s in storage.list_students():
            if s.email == 'jd@mun.ca':
                stu = s
        self.assertEqual(75, stu.quizzes['Quiz1'][0])
        storage.clean()
        storage.close()

    def test_update_grades_fail(self):
        storage = Persist('file.dat')
        with self.assertRaises(KeyError):
            ManualGrading.update_grades('nothere@mun.ca', 'Quiz1')
        storage.clean()
        storage.close()

if __name__ == "__main__":
    unittest.main(verbosity=2)


