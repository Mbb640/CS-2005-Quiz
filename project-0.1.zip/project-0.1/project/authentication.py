import persist
from persist import Student, Instructor



# a made up list of instructors' emails, which will be used for registration 
# a person is allowed to register as an instructor if his email is in this list
instructor_emails = ['john@gmail.com', 'sarah@gmail.com', 'shams@gmail.com', 'anna@gmail.com','brown@mun.ca']

def _is_instructor_email(user_email):
    '''Checks if the user_email is an instructor's email.

    If the user_email is in the list of made up instructors' emails
    it means that the user can register as an instructor. 
    Otherwise, he is restricted from signing up.

    Parameters
    ----------
    user_email : str
        Email which represents the email of the user who wants to register

    Returns
    -------
    bool
        True, if the user_email belongs to a potential (future) instructor
        False, if the user_email does NOT belong to a potential (future) instructor
    '''
    # checking if the user's email is in the list of made up instructors' emails
    # and returning true or false accordingly
    
    if user_email in instructor_emails:
        return True
    else:
        return False

def _registered(inst_email):
    '''Checks if the instructor exists, meaning he is already registered.

    If the instructor is already regisetered, meaning inst_email is in the
    persistent object under key 'instructors', then he cannot re-register

    Parameters
    ----------
    inst_email : str
        The email of the instructor who tries to register

    Returns
    -------
    bool
        True, if there is a registered instructor with that email
        False, if there is not a registered instructor with that email
    '''
    database = persist.Persist('file.dat')
    # retrieving the list of all instructors 
    instructor_list = database.list_instructors()
    # taking one instructor at a time and comparing his email 
    # with the one who is trying to resigter
    for instructor in instructor_list:
        # if a match found, it means the instructor is already registered
        # and a re-registration is prevented
        if instructor.email == inst_email:
            database.close()
            return True
    database.close()
    return False

def exist(stud_email):
    '''Check if a particular student exists.

    If the student already has an account, a second account cannot be created

    Parameters
    ----------
    stud_email : str
        Which the student will be looked for

    Returns
    -------
    bool
        True, if student exists
        False, otherwise
    '''
    database = persist.Persist('file.dat')
    student_list = database.list_students()
    for student in student_list:
        if student.email == stud_email:
            return True
            database.close()
    database.close()
    return False

def validate_instructor(user_email, user_pass):
    '''Validate an instructor and send him to persistnece to be added.

    First, checks if the user is eligible to register as an instructor.
    Only people having an email in the made up list of emails are allowed to register.
    Second, if that user has already registered, re-registration is not allowed.
    If these two tests are passed, a new instructor object is created and sent to persistent.
    Persistence then will handle adding the instructor to the list of instructors.
    Error occurs, if any of the conditions is not satisfied.

    Parameters
    ----------
    user_email : str
        Representing the person's email who is trying to register as an instructor

    user_pass : str
        Representing the person's password who is trying to register as an instructor
    
    Returns
    -------
    bool
        True, if instructor is not registered and is allowed to register
    str
        'not an instructor', if the user is not an instructor
    str
        'already registered', if the user is already registered
    '''
    database = persist.Persist('file.dat')
    if _is_instructor_email(user_email) and not _registered(user_email):
        instructor_obj = Instructor(user_email, user_pass)
        database.add_instructor(instructor_obj)
        database.close()
        return True
    else:
        if not _is_instructor_email(user_email):
            database.close()
            return ('not an instructor')
        elif _registered(user_email):
            database.close()
            return ('already registered')

def validate_login(user_email, user_pass):
    '''Validate user's attempt to login.

    Only existing, meaning registered, users can login.
    The user can be either an instructor or a student.
    Depending on the type of the user, different HTML pages will be rendered in the app

    Parameters
    ----------
    user_email : str
        Representing the user who is trying to login
    
    user_pass : str
        Representing the user's password who is trying to login
    
    Returns
    -------
    str
        'I' if instructor is logged in
    str
        'S' if student is logged in
    bool
        False, if non existent user tries to login
    '''
    database = persist.Persist('file.dat')
    # get the list of all instructors
    instructor_list = database.list_instructors()
    # check if any of the instructor's email matches with the one who is trying to login
    for inst in instructor_list:
        # if a match found, return string I meaning an instructor is found
        if inst.email == user_email and inst.password == user_pass:
            database.close()
            return 'I'
    # if an instructor not found from above, get the list of all students    
    student_list = database.list_students()
    # check if any of the student's email matches with the one who is trying to login
    for student in student_list:
        # if a match found, return string S meaning a student is found
        if student.email == user_email and student.password == user_pass:
            database.close()
            return 'S'
    # if neither an instructor nor a student is found return False
    database.close()
    return False

def create_account(student_email):
    ''' Create an account for a student.

    Only instructors can create accounts for students. Students cannot sign themselves up.
    Instructor enters student's email from provided list of student_emails and account will be created.
    A student will be issued a password in the following format: first part of the email + '555'
    For example, for suren@gmail.com, it will be suren555
    The email will stay the same.

    Parameters
    ----------
    student_email : str
        Representing the student's email
    
    Returns
    -------
    str
        password, generated when a student account is created
    bool
        False, if student already exists
    '''

    # checking if the email belongs to the list of student_emails
    database = persist.Persist('file.dat')

    for i in database.list_students():
        if i.email == student_email:
            return False
    # creating a password out of the first part of the email + '555'
    # for example, if the email is suren@yahoo.com
    # then the password will be 'suren555'
    password = str(student_email.split('@')[0]) + '555' 
    
    # creating the actual student
    stud = Student(student_email, password)

    # storing the student in the persistent file
    database.generate_stud_account(stud)
    database.close()
    return password

