from setuptools import setup

setup(
    name="project",
    version='0.1',
    packages=['project'],


    install_requires =['flask>=1.0.2'],

    package_data={
        '' : ['*.txt','*.pdf'],
        'project' : ['UnitTests/*','docs/*','templates/*'],
    },


    author='Group F',
    description='Group F project submission',
    license='COMP2005 students',
    keywords="flask examples",
)
