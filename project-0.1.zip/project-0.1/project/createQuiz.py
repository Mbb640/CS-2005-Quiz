from persist import Persist, Instructor, Student, Quiz, Question
import collections.abc
"""Quiz Creation.

Classes
-------
Quiz - a collection of questions 
Question - a individual question

Note
----
The classes are imported to this module and then called through flask to create
a quiz. Originally Quizzes and Questions resided in this module however, that created
testing and coupling issues.

Methods
-------
submitQuiz - submit a Quiz to the database.
addToQBank - add a question to the Question bank.
removeFromQBank - remove a question from the Question bank.
changeValueInQBank - change the value of a Question in the question bank.
changeAnswersInQBank - change the answers to a Question in the question bank.
addOptionsInQBank - add an option to a question in  the Question bank.
removeOptionsInQBank - remove an option to a question in the Question bank.
copyFromQBank - copy a question from the question bank.
listQbank - return a list of all the questions in the question bank
"""

def submitQuiz(quiz):
    """Submit a Quiz to the database.

    Parameter
    ---------
    quiz : Quiz object
        The Quiz to be added to the database.
    
    Raises
    ------
    TypeError
        If quiz is not a Quiz.
    """
    if isinstance(quiz, Quiz):
        p = Persist("file.dat")
        p.add_quiz(quiz)
        lst = p.list_students()
        stud = quiz.students
        for i in lst:
            for j in stud:
                if i.email == j:
                    if quiz.Name in i.quizzes:
                        pass
                    else:
                        i.quizzes[quiz.Name] = [0,[]]
                        break
        p.close()
    else:
        raise TypeError


def addToQBank(quest):
    """Add a question to the question bank.

    Parameter
    ---------
    quest : Question object
        The question to be added.

    Raises
    ------
    TypeError
        If argument is not a question.
    """
    if isinstance(quest, Question):
        p = Persist("file.dat")
        try:
            p.get_question(quest)
        except KeyError:
            p.add_question(quest)
        p.close()
    else:
        raise TypeError

def removeFromQBank(quest):
    """Remove a question from the question bank.

    Parameter
    ---------
    quest : Question object
        The question to be removed.
    
    Raises
    ------
    KeyError
        If question is not found.
    """
    p = Persist("file.dat")
    p.remove_question(quest)
    p.close()

def _getFromQBank(quest):
    #Private method get a Question from the question bank
    p = Persist("file.dat")
    q = p.get_question(quest)
    p.close()
    return q

def changeValueInQBank(quest, val):
    """Change the value of a question from the question bank.

    Parameter
    ---------
    quest : Question object
        The question to be modified.
    val : int
        The new value of the Question.
    
    Raises
    ------
    KeyError
        If the question is not found.
    """
    p = Persist("file.dat")
    for q in p.storage['questions']:
        if q.text == quest.text:
            q.changeValue(val)
    p.close()
    

def changeAnswersInQBank(quest,answers):
    """Change the answers to a question from the question bank.

    Parameters
    ----------
    quest : Question object
        The question to be modified.
    answers : List of str
        The new list of correct answers.
    
    Raises
    ------
    KeyError
        If the question is not found.
    """
    p = Persist("file.dat")
    for q in p.storage['questions']:
        if q.text == quest.text:
            q.changeAnswers(answers)
    p.close()

def addOptionsInQBank(quest,opt):
    """Change the options to a question from the question bank.

    Parameters
    ----------
    quest : Question object
        The question to be modified.
    opt : str
        The option to be added.
    
    Raises
    ------
    KeyError
        If the question is not found.
    """
    p = Persist("file.dat")
    exists = False
    for q in p.storage['questions']:
        if q.text == quest.text:
            q.addChoice(opt)
            exists = True
    p.close()
    if exists == False:
        raise KeyError

def removeOptionsInQBank(quest,opt):
    """Change the options to a question from the question bank.

    Parameters
    ----------
    quest : Question object
        The question to be modified.
    opt : String
        The option to be deleted.
    
    Raises
    ------
    KeyError
        If the question is not found or the option is not found.
    """
    p = Persist("file.dat")
    exists = False
    for q in p.storage['questions']:
        if q.text == quest.text:
            q.removeChoice(opt)
            exists = True
    p.close()
    if exists == False:
        raise KeyError

def copyFromQBank(quest):
    """Copy an existing question from the question bank.

    Parameters
    ----------
    quest : Question object
        The question to be copied.
    
    Returns
    -------
    quest : Question object
        The question requested.
    
    Raises
    ------
    KeyError
        If the question is not found.
    """
    return _getFromQBank(quest)

def listQBank():
    """Return a list of all questions in the question bank.

    Returns
    -------
    lst : list of Question objects
        The question bank.
    """
    p = Persist("file.dat")
    lst = p.get_all_questions()
    p.close()
    return lst

def deleteQuiz(quiz):
    """Remove a quiz from the database

    Parameters
    ----------
    quiz : Quiz object
        The quiz to be removed
    """
    p = Persist('file.dat')
    p.remove_quiz(quiz)
    p.close()

def listQuizzes():
    """Return a list of all quizzes

    Returns
    ----------
    lst : list of Quiz objects
        The list of quizzes.
    """
    p = Persist("file.dat")
    lst = p.get_all_quizzes()
    p.close()
    return lst

def getQuiz(quiz):
    """Return a quiz from the list of quizzes

    Parameters
    ----------
    quiz : Quiz object
        The quiz being looked for.

    returns
    -------
    q : Quiz object
        A quiz
    """
    p = Persist("file.dat")
    q = p.get_quiz(quiz)
    p.close()
    return q

def getStudentList():
    """Return all students
    
    Returns
    -------
    lst : list of Student objects
        All Students in the database.
    """
    p = Persist("file.dat")
    lst = p.list_students()
    p.close()
    return lst







    
