"""NOTE:
    This testing module is dependent on the persist module
    if the persist module is changed the setUp method will need
    to be updated.
"""

import unittest
from Auto_Grading import *
import persist
import os


class Test_Auto_Grading(unittest.TestCase):

    data = ["quiz1", "q1", ("o1","o2","o3","o4"), "o1"]

    def setUp(self):
        self.storage = persist.Persist("file.dat")
        student1 = persist.Student('wmail','pswd')
        q1 = persist.Question(self.data[1],self.data[2], [self.data[3]], 1)
        q2 = persist.Question('q2',self.data[2], 'o3', 2)
        quiz = persist.Quiz(self.data[0],[q1,q2],"5","6",3,'me')
        quiz.students = ['wmail']
        self.a1 = persist.Answers('wmail', 'quiz1')
        self.a1.correct_answers = ['o1','o3']
        self.a1.student_answers = ['o1','o2']
        self.a1.question_weights = [1,2]
        self.a1.submitted = True
        student1.quizzes['quiz1']=[0,[self.a1,None,None]]
        self.storage.storage['students'] = [student1]
        self.storage.storage['quizzes'] = [quiz]

    def tearDown(self):
        self.storage.close()
        
    def test_max_score(self):
        self.assertEqual(max_score('quiz1'),3)

    def test_bad_max_score(self):
        with self.assertRaises(TypeError):
            max_score(45)

    def test_find_class_average(self):
        correct_quiz('wmail','quiz1',1)
        self.assertEqual(find_class_average('quiz1'), 1)

    def test_bad_find_class_average(self):
        with self.assertRaises(TypeError):
            find_class_average(["Yellow"])

    def test_find_student_average(self):
        correct_quiz('wmail','quiz1',1)
        self.assertAlmostEqual(find_student_average('wmail','quiz1'), 1)

    def test_badname_find_student_average(self):
        with self.assertRaises(TypeError):
            find_student_average(16, 'quiz1')

    def test_badquiz_find_student_average(self):
        with self.assertRaises(TypeError):
            find_student_average('wmail', [12,13] )

    def test_get_student_attempts(self):
        correct_quiz('wmail','quiz1',1)
        self.assertEqual(get_student_attempts('wmail','quiz1'),[1,None,None])

    def test_badname_get_student_attempts(self):
        with self.assertRaises(TypeError):
            get_student_attempts(45, 'quiz1')

    def test_badquiz_get_student_attempts(self):
        with self.assertRaises(TypeError):
            get_student_attempts('wmail', 13)

    def test_view_student_quiz(self):
        correct_quiz('wmail','quiz1',1)
        self.assertEqual(view_student_quiz('wmail','quiz1',1)
                         ,[(self.data[1],self.data[-1],'o1')
                           ,('q2','o3','o2')])

    def test_badname_view_student_quiz(self):
        with self.assertRaises(TypeError):
            view_student_quiz(48, 'quiz1', 1)

    def test_badquiz_view_student_quiz(self):
        with self.assertRaises(TypeError):
            view_student_quiz('wmail', 1, 1)

    def test_get_instructor_quizzes(self):
        self.assertEqual(get_instructor_quizzes('me'), [self.data[0]])

    def test_bad_get_instructor_quizzes(self):
        with self.assertRaises(TypeError):
            get_instructor_quizzes(58)

if __name__ == '__main__':
    unittest.main(verbosity=2)
