"""
Internal testing for TakeQuiz.py. Coupled with persist.py.
"""

import unittest
import TakeQuiz
import datetime
from persist import *
import os


class TestMethods(unittest.TestCase):

    def setUp(self):
        persist = Persist("file.dat")
        test_student1 = Student("test_email", "testpass")
        test_student2 = Student("test_stu2", "otherpass")
        global test_quiz
        test_quiz = Quiz("test_name", [Question("sample text", ['1', '2', '3', '4'], ['2', '3'], 1)], datetime.datetime, datetime.timedelta.max, 3, "admin")
        persist.add_quiz(test_quiz)
        test_student1.quizzes["test_name"] = [0, []]
        persist.generate_stud_account(test_student1)
        global lst
        lst = persist.list_students()
        persist.close()


  

    def test_check_permissions(self):
        check_return = TakeQuiz.check_permissions("test_email")
        for i in check_return:
            quiz = i
        self.assertTrue(i.Name == test_quiz.Name, msg = check_return)

    def test_bad_permissions(self):

        with self.assertRaises(Exception, msg="Did not raise exception for nonexistent account"):
            TakeQuiz.check_permissions("NotAUser")

    def test_show_question(self):

        test_quiz = TakeQuiz.Quiz("test_name", [TakeQuiz.Question("text", [1, 2, 3, 4], [2, 3], 1)], datetime.datetime, datetime.timedelta.max, 3, "Barrett")
        self.assertTrue(TakeQuiz.show_question(test_quiz, 0) == "text")

    def test_bad_question(self):

        test_quiz = TakeQuiz.Quiz("test_name", [TakeQuiz.Question("text", [1, 2, 3, 4], [2, 3], 1)], datetime.datetime, datetime.timedelta.max, 3, "Barrett")
        with self.assertRaises(IndexError, msg="Does not raise exception when asked to show more questions than quiz has"):
            TakeQuiz.show_question(test_quiz, 1)

    def test_submit_quiz(self):

        self.assertTrue(TakeQuiz.submit_quiz("", "test_email", "test_name") != "Quiz submitted!", 
        msg="Should warn user when submitting blank answer")

    def test_bad_submit(self):

        test_question = TakeQuiz.Question("text", [1, 2, 3, 4], [2, 3], 1)
        with self.assertRaises(Exception, 
        msg="Does not raise exception when asked to submit something that is not a quiz"):
            TakeQuiz.submit_quiz(test_question, "not_a_student", "text")

    def test_pause_quiz(self):
        TakeQuiz.pause_quiz("test_answer", "test_email", "test_name")
        for i in lst:
            if i.email == "test_email":
                for i in i.quizzes["test_name"][1]:
                    if i.student_answers[0] == 'test_answer|||':
                        
                        self.assertTrue(True)
        
        self.fail(msg = "Does not save answer")

    def test_bad_pause(self):
        with self.assertRaises(KeyError):
           TakeQuiz.pause_quiz("test_answer", "test_email", "not_a_quiz")
        #  Pause should raise exception when quiz does not exist.

    def test_resume_quiz(self):
        
        TakeQuiz.pause_quiz("test_answer", "test_email", "test_name")
        for i in lst:
            if i.email == "test_email":
                for i in i.quizzes["test_name"][1]:
                    if i.student_answers[0] == 'test_answer':
                        self.assertTrue(True)
        self.assertTrue(TakeQuiz.resume_quiz("test_name", "test_email") == "test_answer|||")
        

    def test_bad_resume(self):

        # Resume should always run when opening quiz, but if there is nothing to resume, just have a blank answer.
        with self.assertRaises(KeyError):
            (TakeQuiz.resume_quiz("not_a_quiz", "test_email"))


if __name__=="__main__":

    unittest.main(verbosity=2)
    #All code below was intended to reset the data files, but it is not working. Something keeps staying with the files through resets.
    # if os.path.exists("shelve_backend.dat"):
    #     os.remove("shelve_backend.dat")
    # if os.path.exists("shelve_backend.bak"):
    #     os.remove("shelve_backend.bak")
    # if os.path.exists("shelve_backend.dat"):
    #     os.remove("shelve_backend.dir")
    # test_student1 = Student("test_email", "testpass")
    # test_student2 = Student("test_stu2", "otherpass")
    # persist.generate_stud_account(test_student1)
    # persist.generate_stud_account(test_student2)
    # test_quiz = Quiz("test_name", [Question("sample text", ['1', '2', '3', '4'], ['2', '3'], 1)], datetime.datetime, datetime.timedelta.max, 3, "admin")
    # persist.add_quiz(test_quiz)
    # test_student1.quizzes["test_name"] = [0, []]
    # persist.close()
