"""Manual Grading Module.

Makes updates to questions, answers and quizzes stored in 
an imported persistance file.

Methods:
modify_attempt -- Change students grade on quiz
modify_answer -- Change students question answer
modify_quiz_grades -- Change all students grade on a quiz
new_question_answer -- Change correct answers to a question
update_grade -- Update a students grade for a quiz

"""
from persist import Persist, Student
from datetime import datetime

# private method to open persistant storage
def _open_storage():
    storage = Persist('file.dat')
    return storage

# private method to close persistant storage
def _close_storage(storage):
    storage.close()

def modify_student_quiz_grade(student, quiz, grade, note=None):
    """For a given student change their grade on a quiz to a new amount.
    
    Parameters
    ----------
    student : String
        email for student you want to modfiy grade for
    quiz : String
        name of the quiz to modify grade
    grade : int
        new grade for the quiz
    note : String
        Optional note about the modification

    Raises
    ------
    ValueError
        If grade is not between 0 - 100
    KeyError
        If student is not in stored students list
    
    """
    if grade > 100 or grade < 1: raise ValueError('The new grade should be between 0-100.')
    storage = Persist('file.dat')
    found = False
    lst = storage.list_students()
    for s in lst:
        if s.email == student:
            found = True
            s.quizzes[quiz][0] = grade
            break
    storage.storage['students'] = lst
    if found != True: raise KeyError('Incorrect student email.')
    if note != None:
        _modification_note(note, storage.get_quiz(quiz))
    
    storage.close()

def modify_answer(student, quiz, question, new_answer, note=None):
    """Change a students answer to a question on a quiz, and 
    regrade the students quiz with new answer.
    
    Parameters
    ----------
    student : String
        the students email
    quiz : String
        the name of the quiz
    question : String
        the text of the question
    new_answer : String
        The new answer for the question on the quiz
    note : String
        Optional note about the modification

    Raises
    ------
    ValueError
        If new_answer is not a possible choice in quiz answers
    KeyError
        If student is not in stored students list
    
    """
    storage = Persist('file.dat')
    q = storage.get_quiz(quiz)
    place = 0
    found = False
    count = 0
    for quest in q.questions:
        if question == quest:
            for c in new_answer:
                if c in quest.choices:
                    count += 1
            if count == len(new_answer):
                found = True
        if found == True:
            break
        place += 1
    if found == False: raise ValueError('New answer is not a possible choice for the question.')
    found = False
    for s in storage.list_students():
        if s.email == student:
            found = True
            for a in s.quizzes[quiz][1]:
                if a.submitted == True:
                    a.student_answers[place] = new_answer
    if found == False: raise KeyError('Student email not in database.')
    update_grades(student, quiz)
    if note != None:
        _modification_note(note, q)

    storage.close()

def modify_quiz_grades(quiz, grade_change, note=None):
    """Raise the mark of all students on a given quiz.

    Parameters
    ----------
    quiz : String
        The quiz to modify overall grades for
    grade_change : Int
        Amount to increase all grades on the quiz by
    note : String
        Optional note about the modification

    Raises
    ------
    ValueError
        If grade_change is not between 0-100
    """
    if grade_change > 100 or grade_change < 1: raise ValueError('The grade change should be between 0-100.')
    storage = Persist('file.dat')
    q = storage.get_quiz(quiz)
    for s in storage.list_students():
        if quiz in s.quizzes.keys():
            s.quizzes[quiz][0] += grade_change
    if note != None:
        _modification_note(note, q)

    storage.close()

def new_question_answer(quiz, question, new_answers, note=None):
    """Update a question on a quiz to have a new answer or answers, and
    regrade all attempts already taken for the quiz.

    Parameters
    ----------
    quiz : String
        name of the quiz to modify
    question : String
        text of the question
    new_answer : List
        list of new answer(s) for the question
    note : String
        Optional note about the modification

    Raises
    ------
    KeyError
        If question is not found in the quiz

    """
    storage = Persist('file.dat')
    q = storage.get_quiz(quiz)
    found = False
    for quest in q.questions:
        if quest == question:
            found = True
            quest.answers = new_answers
    if found == False: raise KeyError('Question not in quiz.')
    for s in storage.list_students():
        if s in q.students:
            update_grades(s, quiz)
    if note != None:
        _modification_note(note, q)

    storage.close()

def update_grades(student, quiz):
    """Updates a students grade on a quiz to reflect any updates that may have occured.

    Parameters
    ----------
    student : Student
        Student for whom to update grades
    quiz : String
        name of the quiz

    Raises
    ------
    KeyError
        When student is not in database
    """
    storage = Persist('file.dat')
    q = storage.get_quiz(quiz)
    found = False
    for s in storage.list_students():
        if student == s.email:
            stu = s
            found = True
    if found == False: raise KeyError('Student not in database.')
    total = 0
    score = 0
    for quest in q.questions:
        total += quest.value
    for atp in _get_attempts(stu, q):
        place = 0
        for ans in atp.student_answers:
            for a in ans:
                if a in q.questions[place].answers:
                    score += q.questions[place].value
                    break
        atp.score = score/total * 100
    score = 0
    highest = 0
    for atp in _get_attempts(stu, q):
        if atp.score > highest:
            highest = atp.score
    stu.quizzes[q.Name][0] = highest
    storage.storage['students'] = [stu]
    storage.close()

def _modification_note(note, quiz):
    # adds note to quiz with timestamp
    quiz.modifications.append([note, datetime.now()])

def _get_attempts(student, quiz):
    # Generator of a students attempts on a quiz
    # Raise _Empty exception
    atps = student.quizzes[quiz.Name][1]
    for a in atps:
        yield a

def stu_taken_quiz(Quiz):
    # method to return students who have taken quiz for frontend
    studs = []
    storage = _open_storage()
    q = storage.get_quiz(Quiz)
    i = 0
    while i < len(q.students):
        for stu in storage.list_students():
            if stu.email == q.students[i]:
                if stu.quizzes[Quiz][1]:
                    studs.append(stu.email)
    return studs
