'''This is a mock Persist module for testing purposes.

Data structure:
Shelve stores data  in the form of a dictionary.
Data will be stored about instructors, students, quizzes and questions.
Each type of data will have a respective key and a list where they are kept. 

Example structure:
    { 
        "instructors": [instructor1, instructor2, ...]
        "students": [student1, student2, ...]
        "quizzes": [quiz1, quiz2, ... ]
        "questions": [question1, question2, ...]
    }
'''


import shelve
import collections.abc

class Quiz:
    """Quiz Creation.

    Methods:
    --------
    authorize - ensure the person accessing the quiz is the creator
    addQuestion - add a question to the quiz
    modifyQuestionValue - change the value of a question
    changeStart - change the start time of a quiz
    changeEnd - change the end time of a quiz
    addStudents - add a student to a quiz
    copyQuiz - copy the current quiz

    Attributes:
    -----------
    Name : str
        The name of quiz.
    Questions : List of Questions
        The questions in the quiz.
    startTime : str
        The time the quiz availability will begin.
    endTime : str 
        The time the quiz availability will end.
    numOfAttempts : int
        The number of attempts a student is allowed.
    creator : str
        The username of the creator of the quiz.
    students : list of str
        List of usernames for who can take the quiz.
    modifications : list of str
        List of modifications performed on the quiz.
    """
    
    def __init__(self,name,questions,start,end,attempts,user):
        """initializer.

        Parameters
        ----------
        name : str
            The name of the quiz.
        questions : List of Question objects
            List of questions for the quiz.
        start : str
            Start time of the quiz.
        end : str 
            End time of the quiz.
        attempts : int
            Number of attempts allowed for a quiz.
        user : str
            Creator of the quiz.

        Raises
        ------
        ValueError 
            If the user is not a instructor.
        """
        #if isinstance(user,Instructor):
        #This line will be added after
        #Currently it will just create errors
        #Until further implementation
        self.Name = name
        self.questions = questions 
        self.startTime = start
        self.endTime = end
        self.numOfAttempts = attempts
        self.creator = user
        self.students = []
        self.modifications = []
    
    def __eq__(self, other):
        """Define new eq method.
        
        Note
        ----
        Quizzes can be discovered just using their text.

        Parameters
        ----------
        other : str or Quiz object
            The comparison object
        """
        if isinstance(other,str):
            return self.Name == other
        if isinstance(other, Quiz):
            return self.Name == other.Name
            

    def _findQuestion(self,text):
        # return the question being searched for
        # raises value error if it is not found
        
        try:
            for i in self.questions:
                if i == text:
                    return i
        except:
            raise ValueError

    def authorize(self,user):
        """Authorize the user to edit the quiz.

        Parameters
        ----------
        user : str
            The username of the person trying to access the Quiz.

        Returns
        -------
        bool
            True if user is the creator of the quiz, False otherwise.
                    
        Raises:
        -------
        PermissionError
            When the user is not the creator.
        """
        if user == self.creator:
            return True
        else:
            raise PermissionError
        
    def addQuestion(self,question,user):
        """Add a question to the quiz.

        Parameters
        ----------
        question : Question object
            The question to be added.
        user : str
            The username of the person trying to access the Quiz.
        
        Raises
        ------
        TypeError 
            When the object passed is not a question.
        PermissionError 
            When the user is not the creator.
        """
        if self.authorize(user) == True:
            if isinstance(question, Question):
                self.questions.append(question)
            else:
                raise TypeError

    def removeQuestion(self,quest,user):
        """Remove a question from the quiz.

        Parameters
        ----------
        quest : Question object
            The question to be removed.
        user : str
            The username of the person trying to access the Quiz.
        
        Raises
        -----
        ValueError
            When question is not in the quiz. 
        PermissionError
            When the user is not authorized.
        """
        if self.authorize(user) == True:
            self.questions.remove(quest)
             
    def modifyQuestionValue(self,quest,value,user):
        """Change the value of a question.

        Parameters
        ----------
        quest : Question object 
            The question object to be modified.
        value : int 
            The new value of the question.
        user : str
            The username of the person trying to access the Quiz.
        
        Raises
        ------
        ValueError
            When question is not in the quiz or value is less than zero.
        PermissionError
            When the user is not authorized.
        """
        if self.authorize(user) == True:
            if value >= 0:
                i = self._findQuestion(quest)
                i.changeValue(value)
            else:
                raise ValueError
    
    def changeStart(self,start,user):
        """Change the start time of the quiz.

        Parameters
        ----------
        start : str
            The new startTime of the quiz.
        user : str
            The username of the person trying to access the Quiz.

        Raises
        ------
        TypeError
            If string isnt passed.
        """
        if self.authorize(user) == True:
            if isinstance(start, str):
                self.startTime = start
            else:
                raise TypeError
                
    def changeEnd(self,end,user):
        """Change the end time of the quiz.

        Paramters
        ---------
        end : str
            The new endTime of the quiz.
        user : str
            The username of the person trying to access the Quiz.
        
        Raises
        ------
        TypeError
            If string isnt passed.
        """
        if self.authorize(user) == True:
            if isinstance(end, str):
                self.endTime = end
            else:
                raise TypeError
    
    def addStudents(self,stud,user):
        """Specify which students can take the quiz.

        Paramters
        ---------
        stud : str
            The unique username of the student to be added.
        user : str
            The username of the person trying to access the Quiz.
        
        Raises
        ------
        ValueError
            If student username doesnt exist.
        """
        if self.authorize(user) == True:
            p = Persist('file.dat')
            lst = p.list_students()
            found = False
            for i in lst:
                if i.email == stud:
                    self.students.append(stud)
                    found = True
            p.close()
            if found == False:
                raise ValueError
    
    def copyQuiz(self,user):
        """copy the quiz.

        Parameters
        ----------
        user : str
            The username of the person trying to access the Quiz.

        Returns
        -------
        self : Quiz object
            The Quiz this is called on.
        """
        if self.authorize(user) == True:
            return self  


class Question:
    """Question creation.

    Methods
    -------
    changeAnswers - change the answers to a question
    addChoice - add a choice to a question
    removeChoice - remove a choice to a question
    changeValue - change the weight of a question
    copyQuestion - copy a question
    
    Attributes
    ----------
    text : str
        The text of the question.
    choices : list of str
        The choices for the MCQ.
    answers : list of str
        The answers for the MCQ.
    value : int
        The weight of the question.
    """

    def __init__(self,text,options,answers,val):
        """Initializer.

        Parameters
        ----------
        text : str 
            The text of the question.
        options : list of str 
            The list of choices.
        answers : list of str 
            The list of answers.
        val : int
            The value of the question.
        """
        self.text = text
        self.choices = options
        self.answers = answers
        self.value = val

    def __eq__(self, other):
        """Define new eq method.
        
        Note
        ----
        Questions can be discovered just using their text.

        Parameters
        ----------
        other : str or Question object
            The comparison object
        """
        if isinstance(other,str):
            return self.text == other
        if isinstance(other, Question):
            return self.text == other.text
    
    def changeAnswers(self,ans):
        """Change the answers to the question

        Parameter
        ---------
        ans : List of str
            The new answers
        
        Raises
        -------
        TypeError
            If list is not passed
        """
        if isinstance(ans, collections.abc.Sequence):
            self.answers = ans
        else:
            raise TypeError
 
    def addChoice(self,choice):
        """Add a choice to a question.

        Parameter
        ---------
        choice : str
            The choice to be added.
        
        Raises
        ------
        TypeError 
            If choice is not a string.
        """
        if isinstance(choice, str):
            self.choices.append(choice)
        else:
            raise TypeError

    def removeChoice(self,choice):
        """Add a choice to a question.

        Parameters
        ----------
        choice : str
            The choice to be removed.
        
        Raises
        ------
        ValueError
            If the choice isn't found.
        """
        self.choices.remove(choice)

    def changeValue(self,val):
        """Change the value of a question.

        Parameters
        ----------
        val : int
            The new value.
        
        Raises
        ------
        ValueError
            When val is less than 0.
        """
        if val >= 0:
            self.value = val
        else:
            raise ValueError

    def copyQuestion(self):
        """Copy the question.

        Returns
        -------
        self : Question object
            The current Question.
        """
        return self 

class Student():
    """Represents a student.

    Creates a student with initial attributes
    
    Parameters
    ----------
    email : str
        Student's email
    password : str
        Student's password
    quizzes : dict
        A dictionary of quizzes taken by the student
    """
    def __init__(self, email, password):
        self.email = email
        self.password = password
        self.quizzes = {}
    
class Instructor():
    """Represents an Instructor.
    
    Creates an instructor with initial attributes
    
    Parameters
    ----------
    email : str
        Instructor's email
    password : str
        Instructor's password
    """

    def __init__(self, email, password):
        self.email = email
        self.password = password


class Answers:
    """Holds student answers for grading.
    Parameters
    ----------
    student_id: string
        Id of the student currently taking the quiz.
    quiz_id: string
        Id of the quiz currently being displayed.
        
    Attributes
    ----------
    student_id: string
        Id of the student who gave the answers.
    quiz_id: string
        Id of the quiz that the student gave answers for.
    student_answers: array of strings
        List of answers from student in same order as questions. Questions that were not answered are blank strings.
    correct_answers: array of strings
        List of answers given by instructor upon quiz creation. In same order as student_answers.
    score: int
        The score for this attempt.
    """
    def __init__(self, student_id, quiz_id):
        self.student_id = student_id
        self.quiz_id = quiz_id
        self.student_answers = []
        self.correct_answers = []
        self.question_weights = []
        self.score = []
        self.submitted = False

    def save_answers(self, answer_string):
        """On pause or submit, creates two lists with the correct answers and the student's answers to pass to
        persistence or grade correction as needed.
        
        Parameters
        ----------
        answer_string: string
            String given by flask. ALl student answers seperated by '|||'. Blank answers are ''.
        
        Returns
        -------
        None
        """
        answer_array = answer_string.split("|||")
        persist = Persist("file.dat")
        self.student_answers = answer_array
        for i in range(0, len(persist.get_quiz(self.quiz_id).questions)):
            self.question_weights.append(persist.get_quiz(self.quiz_id).questions[i].value)
        for i in persist.get_quiz(self.quiz_id).questions:
            self.correct_answers.append(i.answers)
        persist.close()

    


class Persist():
    """ Handles persistence for quiz app objects

    Parameters
    ----------
    filename : str
        The file name of the persistence object where the data will be stored

    Methods
    -------
        Persist(filename) - open the persistence file
        list_instructors -  retrieve a list of all instructors
        list_students - retrieve a list of all students
        add_instructor(instructor) - add an instructor to the list of instructors 
        add_quiz(quiz) - add a quiz to the list of quizzes
        get_quiz(quiz) - retrieve a specific quiz
        remove_quiz(quiz) - delete a specific quiz from the list of quizzes
        add_question(question) - add a question to the list of questions
        get_question(question) - retrieve a specific question
        remove_question(question) - delete a specific question from the list of questions
        clear - empty the persistnce file
        close - close the persistence file
    """
    # a made up list of instructors' emails meaning if someone is 
    # an instructor, his email should be in this list
    # later, this list will be used to identify if the user is a student or an istructor
    instructor_emails = ['john@gmail.com', 'sarah@gmail.com', 'bob@yahoo.com','brown@mun.ca']
    
    def __init__(self, filename):
        """Open a Persist object to store data.
        
        Parameters
        ----------
        str
            filename -> the file name of the persistence object where the data will be stored to and retrieved from
        
        Returns
        -------
        None
        """
        self.storage = shelve.open(filename, writeback=True)

    def list_instructors(self):
        """Retrieve a list of all instructors.
        
        Returns
        -------
        List
            A list of all registered instructor objects
        """

        if 'instructors' in self.storage:
            return self.storage['instructors']
        else:
            return []
    
    def list_students(self):
        """Retrieve a list of all students.
        
        Returns
        -------
        List
            A list of all student objects
        """

        if 'students' in self.storage:
            return self.storage['students']
        else:
            return []

    def add_instructor(self, instructor):
        """Add an instructor to the list of instructors in the persistence file.

        In the registration process, if there is no any registered instructor, 
        then an empty list of instructors is created and the given instructor is put there.
        If there are already registered instructors, then the given instructor is added to that list

        Parameters
        ----------
        instructor : Instructor Object
            An instructor object which is going to be added to the list of instructors 
        
        Returns
        -------
        bool 
            True, if instructor is successfully added
            False, otherwise
        """
        if 'instructors' in self.storage:
            temp = self.storage['instructors']
            temp.append(instructor)
            self.storage['instructors'] = temp
            return True
        else:
            self.storage['instructors'] = [instructor]
            return True
        return False
    

    def add_quiz(self, quiz):
        """Add a quiz to the list of quizzes.

        When a new quiz is created, it is added to the list of quizzes.
        If a quiz with that quiz already exists it deletes it then adds the new one.
        
        Parameters
        ----------
        quiz : Quiz object
            A quiz object which will be added to the list of quizzes when created
        
        Returns
        -------
        bool 
            True, if quiz is successfully put
            False, otherwise

        """
        if 'quizzes' in self.storage:
            temp = self.storage['quizzes']
            exists = False
            for i in temp:
                if i.Name == quiz.Name:
                    exists = True
                    break
                else:
                    exists = False
            if exists == True:
                self.remove_quiz(quiz)
                temp = self.storage['quizzes']
                temp.append(quiz)
            else:
                temp.append(quiz)
            self.storage['quizzes'] = temp
            return True
        else:
            self.storage['quizzes'] = [quiz]
            return True
        return False

    
    def get_quiz(self, quiz):
        """Retrieve a specific quiz from the list of quizzes.
        
        Parameters
        ----------
        quiz : str or Quiz object
            A specific quiz that should be retrieved
        
        Raises
        ------
        KeyError 
            if the requested quiz does not exist

        Returns
        -------
        Quiz
            quiz -> the quiz that was being looked for
        """
        list_quizzes = self.storage['quizzes']
        if isinstance(quiz, str):
            for q in list_quizzes:
                if q.Name == quiz:
                    return q
            raise KeyError('The requested quiz does not exist')
        else:
            for q in list_quizzes:
                if q.Name == quiz.Name:
                    return q
            raise KeyError('The requested quiz does not exist')

    def get_all_quizzes(self):
        """Retrieve all the quizzes from the persistnece file.

        Returns
        --------
        List
            a list of all the quizzes
        """
        
        if 'quizzes' in self.storage:
            return self.storage['quizzes']
        else:
            return []
    
    def remove_quiz(self, quiz):
        """Remove a speicific quiz from the list of quizzes.
        
        Parameters
        ----------
        quiz : str or Quiz object
           The quiz that should be removed from the list of quizzes
        
        Raises
        ------
        KeyError 
            if the requested quiz does not exist

        Returns
        -------
        bool
            True, if the quiz is found and removed
            Error is raised otherwise
        """
        list_quizzes = self.storage['quizzes']
        if isinstance(quiz, str):
            for q in list_quizzes:
                if q.Name == quiz:
                    list_quizzes.remove(q)
                    self.storage['quizzes'] = list_quizzes
                    return True
            raise KeyError('The requested quizz does not exist')
        else:
            for q in list_quizzes:
                if q.Name == quiz.Name:
                    list_quizzes.remove(q)
                    self.storage['quizzes'] = list_quizzes
                    return True
            raise KeyError('The requested quizz does not exist')


    def add_question(self, question):
        """Add a question to the list of questions.
        
        Parameters
        ----------
        question : Question object
            The question that should be added
        
        Returns
        -------
        bool
            True, if the question is successfully added
            False, otherwise
        """
        if 'questions' in self.storage:
            temp = self.storage['questions']
            temp.append(question)
            self.storage['questions'] = temp
            return True
        else:
            self.storage['questions'] = [question]
            return True
        return False
    
    def get_question(self, question):
        """Retrieve a speicific question from the list of questions.
        
        Parameters
        ----------
        Question : str or Question object
            The question that should be retrieved

        Raises
        ------
        KeyError
            if, the requested question does not exist

        Returns
        -------
        Question : Question object
             The question that was being looked for
        """
        list_questions = self.storage['questions']
        if isinstance(question, str):
            for q in list_questions:
                if q.text == question:
                    return q
            raise KeyError('The requested question does not exist')
        else:
            for q in list_questions:
                if q.text == question.text:
                    return q
            raise KeyError('The requested question does not exist')


    def get_all_questions(self):
        """Retrieve all the questions from the persistnece file.

        Returns
        --------
        List
            a list of all the questions
        """
        if 'questions' in self.storage:
            return self.storage['questions']
        else:
            return []
         
    def remove_question(self, question):
        """Remove a speicific question from the list of questions.
        
        Parameters
        ----------
        Question : str
            The question that should be removed
        
        Raises
        ------
        KeyError 
            if the requested question does not exist 
        
        Returns
        -------
        bool
            True, if question found and removed
            Error raised otherwise
        """
        list_questions = self.storage['questions']
        for q in list_questions:
            if q == question:
                list_questions.remove(q)
                self.storage['questions'] = list_questions
                return True
        raise KeyError('The requested question does not exist')
    
    def generate_stud_account(self, student):
        """Create an account for a specific student.
        
        Parameters
        ----------
        student : Student object
            A specific student for whome an account should be created

        Returns
        -------
        bool
            True, if account is created
            False, if account is not created
        """
        if 'students' in self.storage:
            temp = self.storage['students']
            temp.append(student)
            self.storage['students'] = temp
            return True
        else:
            self.storage['students'] = [student] 
            return True
        return False

    def clean(self):
        """Clear the persistence file"""
        self.storage.clear()
    
    def close(self):
        '''Close the persistence object'''
        self.storage.sync()
        self.storage.close()
    
