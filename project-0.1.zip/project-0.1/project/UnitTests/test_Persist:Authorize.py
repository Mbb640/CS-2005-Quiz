import unittest, tempfile, os.path, stat, datetime
from persist import Persist, Quiz, Question, Instructor, Student
from authentication import validate_instructor, validate_login, create_account

global database
database = Persist('file.dat')

class TestQuiz(unittest.TestCase):

    instructor_data = [
                    ('john@gmail.com', 'jjj111'),
                    ('sarah@gmail.com', 'sss111'),
                    ('bob@gmail.com', 'bbb111')
                ]
    
    student_data = [
                    ('ben@yahoo.com', 'suren555'),
                    ('anna@yahoo.com', 'anna555'),
                    ('hayk@yahoo.com', 'hayk555')
                ]

    question_data = [
                        ('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5),
                        ('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4),
                        ('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3),
                        ('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
                    ]

    def setUp(self):
        self.pdir = tempfile.TemporaryDirectory()
        self.dfname = os.path.join(self.pdir.name, 'file.dat')
        self.persist = Persist('file.dat')
        self.persist.clean()

        for p in self.instructor_data:
            instructor = Instructor(p[0], p[1])
            self.persist.add_instructor(instructor)
        
        for p in self.student_data:
            student = Student(p[0], p[1])
            self.persist.generate_stud_account(student)

    def tearDown(self):
        self.persist.close()
        self.pdir.cleanup()
    
    def test_check_fixture(self):
        self.persist.add_instructor(Instructor('john@gmail.com', 'jjj111'))
        list_of_instructors = self.persist.list_instructors()
        self.assertEqual(list_of_instructors[0].email, 'john@gmail.com')
        self.assertEqual(list_of_instructors[0].password, 'jjj111') 

    def test_validate_proper_instructor(self):
        email = 'brown@mun.ca'
        password = 'jjj111'
        self.assertEqual(validate_instructor(email, password), True)

    def test_check_unauthorized_instructor(self):
        email = 'invalidEmail@gmail.com'
        password = 'invalidPassword'
        self.assertEqual(validate_instructor(email, password), 'not an instructor')

    def test_check_existing_instructor(self):
        email = 'john@gmail.com'
        password = 'jjj111'
        database.add_instructor((Instructor('john@gmail.com', 'jjj111')))
        self.assertEqual(validate_instructor(email, password), 'already registered')


    def test_validate_instructor_login(self):
        email = 'john@gmail.com'
        password = 'jjj111'
        database.add_instructor((Instructor('john@gmail.com', 'jjj111')))
        self.assertEqual(validate_login(email, password), 'I')

    def test_check_invalid_user_login_when_empty(self):
        email = 'invalidEmail@yahoo.com'
        password = 'invalidPassword'
        self.assertFalse(validate_login
                         (email, password))

    def test_check_invalid_user_login_when_populated(self):
        for p in self.instructor_data:
            instructor = Instructor(p[0], p[1])
            database.add_instructor(instructor)
        
        for p in self.student_data:
            student = Student(p[0], p[1])
            database.generate_stud_account(student)

        email = 'invalidEmail@yahoo.com'
        password = 'invalidPassword'
        self.assertFalse(validate_login(email, password))
        database.clean()

    def test_create_student_account_when_empty_pass(self):
        email = 'suren@yahoo.com'
        password = 'suren555'
        self.assertEqual(create_account(email), 'suren555')

    
    def test_create_student_account_when_populated_pass(self):
        email = 'suren@yahoo.com'
        password = 'suren555'
        for p in self.student_data:
            student = Student(p[0], p[1])
            database.generate_stud_account(student)
        self.assertEqual(create_account(email), 'suren555')
        
    def test_create_account_for_existing_student_fail(self):
        email = 'suren@yahoo.com'
        password = 'suren555'
        
        create_account('suren@yahoo.com')
        self.assertFalse(create_account(email))

    def test_validate_student_login(self):
        email = 'suren@yahoo.com'
        password = 'suren555'
        create_account("suren@yahoo.com")
        self.assertEqual(validate_login(email, password), 'S')
        database.clean()

    #There is no fail possible for this
    def test_add_instructor_pass(self):
        self.persist.add_instructor(Instructor('john@gmail.com', 'jjj111'))
        list_of_instructors = self.persist.list_instructors()
        self.assertEqual(list_of_instructors[3].email, 'john@gmail.com')
        self.assertEqual(list_of_instructors[3].password, 'jjj111')


    #There is no fail possible for this
    def test_add_quiz_pass(self):
        name = 'Quiz1'
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        start = '1pm'
        end = '2pm'
        attempts = 3
        instructor = 'john@gmail.com'
        self.persist.add_quiz(Quiz(name, [q1, q2], start, end, attempts, instructor))
        quiz_list = self.persist.get_all_quizzes()
        self.assertEqual(quiz_list[0].Name, 'Quiz1')
        self.assertEqual(quiz_list[0].numOfAttempts, 3)
        self.assertEqual(quiz_list[0].creator, 'john@gmail.com')

    def test_get_quiz_pass(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q4 = Question('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
        quiz1 = Quiz('Quiz1', [q1, q3], '1pm', '2pm', 3, 'bob@gmail.com')
        quiz2 = Quiz('Quiz2', [q2, q4], '2pm', '3pm', 2, 'sarah@gmail.com')
        quiz3 = Quiz('Quiz3', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quizzes = [quiz1, quiz2, quiz3]
        for q in quizzes:
            self.persist.add_quiz(q)
        self.assertEqual(self.persist.get_quiz(quiz2).Name, 'Quiz2')
        self.assertEqual(self.persist.get_quiz(quiz2).startTime, '2pm')
        self.assertEqual(self.persist.get_quiz(quiz2).endTime, '3pm')
        self.persist.clean()

    def test_get_quiz_fail(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q4 = Question('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
        quiz1 = Quiz('Quiz1', [q1, q3], '1pm', '2pm', 3, 'bob@gmail.com')
        quiz2 = Quiz('Quiz2', [q2, q4], '2pm', '3pm', 2, 'sarah@gmail.com')
        quiz3 = Quiz('Quiz3', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')

        quiz7 = Quiz('Quiz7', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quiz8 = Quiz('Quiz8', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quiz4 = Quiz('Quiz4', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quizzes = [quiz1, quiz2, quiz3]
        for q in quizzes:
            self.persist.add_quiz(q)
        with self.assertRaises(KeyError, msg = 'The requested quiz does not exist'):
            self.persist.get_quiz(quiz7)
            self.persist.get_quiz(quiz8)
            self.persist.get_quiz(quiz4)
        self.persist.clean()

    def test_remove_quiz_pass(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q4 = Question('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
        quiz1 = Quiz('Quiz1', [q1, q3], '1pm', '2pm', 3, 'bob@gmail.com')
        quiz2 = Quiz('Quiz2', [q2, q4], '2pm', '3pm', 2, 'sarah@gmail.com')
        quiz3 = Quiz('Quiz3', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quizzes = [quiz1, quiz2, quiz3]
        for q in quizzes:
            self.persist.add_quiz(q)
        self.assertTrue(self.persist.remove_quiz(quiz2))
        self.assertTrue(self.persist.remove_quiz(quiz3))
        self.assertTrue(self.persist.remove_quiz(quiz1))
        self.persist.clean()

    def test_remove_quiz_fail(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q4 = Question('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
        quiz1 = Quiz('Quiz1', [q1, q3], '1pm', '2pm', 3, 'bob@gmail.com')
        quiz2 = Quiz('Quiz2', [q2, q4], '2pm', '3pm', 2, 'sarah@gmail.com')
        quiz3 = Quiz('Quiz3', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')

        quiz7 = Quiz('Quiz7', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quiz8 = Quiz('Quiz8', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quiz4 = Quiz('Quiz4', [q3, q2], '10am', '11am', 4, 'melisa@gmail.com')
        quizzes = [quiz1, quiz2, quiz3]
        for q in quizzes:
            self.persist.add_quiz(q)
        with self.assertRaises(KeyError, msg = 'The requested quiz does not exist'):
            self.persist.remove_quiz(quiz7)
            self.persist.remove_quiz(quiz8)
            self.persist.remove_quiz(quiz4)
        self.persist.clean()

    #There is no fail possible for this
    def test_add_question_pass(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        self.persist.add_question(q1)
        question_list = self.persist.get_all_questions()
        self.assertEqual(question_list[0].text, 'Capital of Canada?')
        self.assertEqual(question_list[0].value, 5)
        self.persist.clean()

    def test_get_question_pass(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q4 = Question('Capital of Armenia?', ['Yerevan', 'Tbilisi', 'Tehran'], ['answer1', 'answer2'], 7)
        question_list = [q1, q2, q3, q4]
        for q in question_list:
            self.persist.add_question(q)
        self.assertEqual(self.persist.get_question(q3).text, 'Capital of USA?')
        self.assertEqual(self.persist.get_question(q3).value, 3)
        self.persist.clean()

    def test_get_question_fail(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)

        q4 = Question('Capital of China?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        q5 = Question('Capital of Japan?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        question_list = [q1, q2, q3]
        for q in question_list:
            self.persist.add_question(q)
        with self.assertRaises(KeyError, msg = 'The question does not exist at all'):
            self.persist.get_question(q4)
            self.persist.get_question(q5)
        self.persist.clean()

    def test_remove_question_pass(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        question_list = [q1, q2, q3]
        for q in question_list:
            self.persist.add_question(q)
        self.assertTrue(self.persist.remove_question(q3))
        self.assertTrue(self.persist.remove_question(q1))
        self.persist.clean()

    def test_remove_question_fail(self):
        q1 = Question('Capital of Canada?', ['Toronto', 'Ottawa', 'Montreal'], ['answer1', 'answer2'], 5)
        q2 = Question('Capital of France?', ['Paris', 'Lyon', 'London'], ['answer1', 'answer2'], 4)
        q3 = Question('Capital of USA?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)

        q5 = Question('Capital of Japan?', ['Los Angeles', 'Washington', 'Miami'], ['answer1', 'answer2'], 3)
        question_list = [q1, q2, q3]
        for q in question_list:
            self.persist.add_question(q)
        with self.assertRaises(KeyError, msg = 'The question does not exist at all to be removed'):
            self.persist.get_question(q5)
        self.persist.clean()

    #There is no fail possible for this
    def test_generate_stud_account_pass(self):
        self.assertTrue(self.persist.generate_stud_account(Student('suren@yahoo.com', 'suren555')))



if __name__ == "__main__":
    unittest.main(verbosity=2)
